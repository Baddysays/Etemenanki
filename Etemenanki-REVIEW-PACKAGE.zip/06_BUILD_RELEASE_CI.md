# 06 — Сборка, релиз, CI

## Локальная сборка

```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH="C:\Qt\6.8.0\msvc2022_64"
cmake --build build --config Release
.\build\Release\Etemenanki.exe
```

POST_BUILD копирует tools, assets, bootstrap в `build/Release/`.

## Python для разработки

```powershell
python -m venv .venv
pip install -r tools/requirements-pdf.txt
```

Путь пишется в `tools/python_path.txt` (или используется .venv автоматически).

## Установщик

- `installer/EtemenankiSetup.iss` — Inno Setup 6
- Имя exe: **Etemenanki.exe**
- Скрипт: `scripts/install-etemenanki.ps1`

## GitHub Actions

| Workflow | Файл | Назначение |
|----------|------|------------|
| CI | `.github/workflows/ci.yml` | Сборка на push |
| Release | `.github/workflows/release-windows.yml` | Артефакты релиза |

**Известная проблема CI:** `install-qt-action` — модули Qt; исправлено на `qtpdf` (без qtquickcontrols2 как отдельного module name). Release workflow может требовать проверки на runner.

## OTA

`releases/update.json`:

```json
{
  "version_code": 100,
  "version_name": "1.0.0",
  "setup_url": "...",
  "portable_url": "...",
  "release_notes": "..."
}
```

Проверка: Settings → Updates → `setup.checkForUpdates()`.

## Portable zip

Содержимое `build/Release/` + зависимости Qt (windeployqt при packaging).  
Ручная загрузка на release v1.0.0 если CI failed.

## Версии

- `CMakeLists.txt`: PROJECT_VERSION 1.0.0
- `ETE_VERSION_CODE` 100
- `cpp/version.h.in` → generated/version.h
