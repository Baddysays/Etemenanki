# 07 — Известные проблемы и исправления

## Исправлено в ходе разработки

Полная таблица последней волны (10 пунктов + установщик): **`10_CHANGELOG_FIXES.md`**.

### Критичные

1. **Fatal: engine.rootObjects() empty**  
   - Причина: `font.family` на `Window` в SetupWizard  
   - Fix: убраны свойства font с корня Window  

2. **Мастер: 0 GB RAM, пустые модели**  
   - Причина: переход на шаг 2 до probe; нет NOTIFY на hardware  
   - Fix: probeReady, hardwareChanged, блокировка «Далее»  

3. **Кириллица «????» в списке моделей**  
   - Причина: `print(json)` на Windows ломает UTF-8 в pipe  
   - Fix: `emit_json()` → stdout.buffer UTF-8  

4. **QString::arg: hw_vram_required , 4**  
   - Причина: uiTr возвращал ключ до setAppSettings  
   - Fix: AppUiStrings::text напрямую; refresh после setAppSettings  

### UX

5. Установленные модели не отображались → `ollama_installed`, метка «Установлена»  
6. Все модели «рекомендуется» → ужесточена логика recommend_models  
7. Сырой JSON в логе шага 3 → текстовые сообщения  
8. Квадратные CheckBox → OptionCard, галочки по умолчанию on  

## Открытые / на проверку ревьюером

| Тема | Детали |
|------|--------|
| CI Release workflow | Может падать на Qt install; portable залит вручную |
| etemenanki-setup.exe | Может отсутствовать в release если CI failed |
| OCR для скан-PDF | Не реализовано |
| translator_backend.cpp | Большой файл, сложность сопровождения |
| VRAM detection | Часто только через nvidia-smi; иначе null |
| Лицензия AGPL PyMuPDF | Документировать для дистрибуции |
| Stale EtemenankiQt.exe | Может остаться в build от старых сборок |

## Логи для отладки

| Файл | Где |
|------|-----|
| `qml_startup.log` | Рядом с Etemenanki.exe |
| `python_debug.log` | AppData / etemenanki debug dir (см. document_loader) |

## Тест-сценарии для ревью

- [ ] Чистая Windows: нет Python, нет Ollama  
- [ ] Ollama с translategemma:4b уже установлена  
- [ ] Смена языка UI EN ↔ RU  
- [ ] PDF DOCX перевод + сохранение  
- [ ] Пропуск мастера → повторный запуск из настроек  
- [ ] Help → клик email/telegram  
