# Etemenanki — пакет для ревью проекта

**Версия документации:** 2026-05-29  
**Продукт:** Etemenanki 1.0.0 (build 100)  
**Автор:** baddysays · hello@baddysays.ru · [@baddysays](https://t.me/baddysays)  
**Репозиторий:** https://github.com/Baddysays/Etemenanki

---

## Как читать этот пакет

Документы пронумерованы — читайте по порядку для полного погружения «от и до».

| № | Файл | Содержание |
|---|------|------------|
| 00 | `00_README_REVIEWER.md` | Этот файл — оглавление |
| 01 | `01_PROJECT_OVERVIEW.md` | Что за продукт, цели, аудитория |
| 02 | `02_ARCHITECTURE_AND_CODE.md` | Стек, модули C++/QML/Python, потоки данных |
| 03 | `03_DESIGN_AND_UI.md` | Палитра, экраны, мастер настройки, UX-решения |
| 04 | `04_REQUIREMENTS_AND_WISHES.md` | Пожелания заказчика и как они реализованы |
| 05 | `05_SETUP_WIZARD_AND_BOOTSTRAP.md` | Первый запуск, probe, модели, зависимости |
| 06 | `06_BUILD_RELEASE_CI.md` | Сборка, установщик, GitHub, OTA |
| 07 | `07_KNOWN_ISSUES_AND_FIXES.md` | Исправленные баги и открытые вопросы |
| 08 | `08_CODE_MAP.md` | Карта файлов репозитория |
| 09 | `09_REVIEW_CHECKLIST.md` | Чеклист для ревьюера |
| 10 | `10_CHANGELOG_FIXES.md` | Последние 10 багфиксов + установщик |

В папке `reference/` — копии ключевых конфигов (каталог моделей, манифест bootstrap, update.json).

---

## Кратко о проекте

**Etemenanki** — настольное приложение Windows для перевода документов (PDF, DOCX, TXT, таблицы, субтитры и др.) с сохранением структуры где возможно. Перевод через **Ollama** локально или **OpenAI-compatible API** в облаке.

Стек: **Qt 6.8 + QML + C++20**, вспомогательные скрипты **Python 3**, опционально **pdf2zh** (PDFMathTranslate).

---

## Что проверить в первую очередь

1. **Запуск:** `build/Release/Etemenanki.exe` — главное окно и мастер настройки.
2. **Код ядра:** `cpp/translator_backend.cpp`, `cpp/document_loader.cpp`.
3. **UI:** `qml_cpp/Main.qml`, `qml_cpp/SetupWizard.qml`, `qml_cpp/EtePalette.qml`.
4. **Bootstrap:** `tools/bootstrap/bootstrap.py` — probe/install.
5. **Локализация:** `cpp/app_ui_strings*.inc`, генераторы в `tools/gen_*_ui_strings.py`.

---

## Контакты для вопросов по ревью

- Почта: hello@baddysays.ru  
- Telegram: https://t.me/baddysays  
- GitHub Issues: https://github.com/Baddysays/Etemenanki/issues
