# 04 — Требования и пожелания заказчика

Документ фиксирует запросы из цикла разработки и статус реализации.

## Продукт и брендинг

| Пожелание | Статус |
|-----------|--------|
| Название **Etemenanki** (не EtemenankiQt) | ✅ CMake target, exe, installer |
| Публикация на GitHub Baddysays/Etemenanki | ✅ |
| Чистый репозиторий без review/tests/legacy | ✅ Удалены лишние папки |
| Контакты baddysays в справке | ✅ HelpWindow: email, Telegram |

## Локализация

| Пожелание | Статус |
|-----------|--------|
| Минимум английский UI (статусы, строки) | ✅ uiTr, gen_*_ui_strings |
| 10 языков в настройках | ✅ AppUiStrings |
| Кириллица в мастере без «????» | ✅ emit_json UTF-8, label_ru/en |

## Установщик «в один клик» (стиль Saylat)

| Пожелание | Статус |
|-----------|--------|
| Проверка зависимостей | ✅ bootstrap probe |
| Рекомендация моделей по железу | ✅ hardware_tier + recommend_models |
| Скачивание pdf2zh, pip, ollama pull | ✅ bootstrap install |
| GitHub updates (update.json) | ✅ SetupManager.checkForUpdates |
| Inno Setup + CI workflow | ✅ installer/, workflows (CI может требовать доработки Qt modules) |

## Мастер первого запуска

| Пожелание | Статус |
|-----------|--------|
| Анализ RAM/GPU | ✅ probe |
| Видеть установленные модели Ollama | ✅ ollama_installed, «Установлена» |
| Корректные рекомендации (не все подряд) | ✅ fits_hardware + tier picks |
| Проверка Python | ✅ python_path, version, libs_ok |
| Понятный шаг «Установить» | ✅ OptionCard, summary, лог |
| Галочки по умолчанию включены | ✅ selected: true |
| Не квадратные чекбоксы | ✅ OptionCard design |

## Исправления по багам

| Проблема | Решение |
|----------|---------|
| Приложение не запускается | Убран `font` с корня Window в SetupWizard |
| «0 GB RAM», пустой список моделей | Сигналы hardwareChanged, ждать probe перед «Далее» |
| Сырой JSON в логе | Человекочитаемые строки [scan]/[install] |
| QString::arg hw_vram_required | uiTr через AppUiStrings, refresh после setAppSettings |

## Ожидания ревьюера (неформальные)

- Оценить читаемость C++ (translator_backend большой — кандидат на рефакторинг).
- Проверить лицензии: PyMuPDF AGPL, pdf2zh, Qt.
- Пройти мастер на чистой VM и на машине с уже установленным Ollama.
- UI/UX: согласованность SetupWizard ↔ SettingsWindow ↔ Main.
