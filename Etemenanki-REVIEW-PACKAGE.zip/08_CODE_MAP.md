# 08 — Карта файлов репозитория

```
Etemenanki/
├── CMakeLists.txt              # Target Etemenanki, POST_BUILD copy
├── README.md
├── .gitignore
│
├── cpp/                        # C++ ядро
│   ├── main.cpp                # Entry, QML engine, context properties
│   ├── app_settings.*          # QSettings, models, cloud, uiText
│   ├── app_ui_strings.*        # Локализация + .inc
│   ├── translator_backend.*    # Перевод, Ollama, cloud, PDF
│   ├── document_loader.*       # Python extract/export
│   ├── document_format.*       # HTML/structure export
│   ├── setup_manager.*         # Мастер, bootstrap process
│   ├── translation_workflow.*  # Workflow steps
│   ├── external_pdf_translate_worker.*
│   ├── version.h.in
│   └── runtime_config.h.in
│
├── qml_cpp/                    # UI
│   ├── Main.qml
│   ├── SetupWizard.qml
│   ├── SettingsWindow.qml
│   ├── HelpWindow.qml
│   ├── LangPicker.qml
│   ├── TranslationHub.qml
│   └── EtePalette.qml
│
├── assets/
│   ├── models_catalog.json
│   └── branding/
│
├── tools/
│   ├── bootstrap/
│   │   ├── bootstrap.py
│   │   └── install_manifest.json
│   ├── extract_document.py
│   ├── export_document.py
│   ├── pdf_layout.py
│   ├── pdf_engines.py
│   ├── pdf2zh_runner.py
│   ├── setup_pdf2zh.ps1
│   ├── requirements-pdf.txt
│   ├── gen_main_ui_strings.py
│   └── gen_status_ui_strings.py
│
├── engines/
│   ├── python/README.md
│   └── pdf2zh/README.md
│
├── installer/
│   └── EtemenankiSetup.iss
│
├── scripts/
│   └── install-etemenanki.ps1
│
├── releases/
│   ├── update.json
│   └── RELEASE_NOTES_v1.0.0.md
│
├── docs/
│   ├── DLYA-POLZOVATELYA.md
│   ├── INSTALLER.md
│   └── review/                 # ← этот пакет
│
└── .github/workflows/
    ├── ci.yml
    └── release-windows.yml
```

## Строки кода (ориентир)

| Файл | ~строк | Критичность |
|------|--------|-------------|
| translator_backend.cpp | 1700+ | Высокая |
| document_loader.cpp | 1400+ | Высокая |
| Main.qml | 1100+ | Высокая |
| SetupWizard.qml | 600+ | Средняя |
| bootstrap.py | 400+ | Средняя |
| setup_manager.cpp | 450+ | Средняя |

## Зависимости между модулями

```
Main.qml
  ├── settings (AppSettings)
  ├── backend (TranslatorBackend) ──► DocumentLoader
  │                              └──► ExternalPdfTranslateWorker
  └── setup (SetupManager) ──► bootstrap.py
```
