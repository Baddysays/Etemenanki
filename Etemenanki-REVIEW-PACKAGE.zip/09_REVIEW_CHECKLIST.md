# 09 — Чеклист для ревьюера

## A. Продукт и документация

- [ ] README соответствует текущему имени Etemenanki.exe
- [ ] docs/DLYA-POLZOVATELYA понятен конечному пользователю
- [ ] Контакты baddysays актуальны в Help и install_manifest.json
- [ ] RELEASE_NOTES отражают v1.0.0 scope

## B. Архитектура и код

- [ ] Нет утечек процессов QProcess (setup, pdf2zh)
- [ ] Обработка ошибок Python extract (сообщения локализованы)
- [ ] Thread-safety DocumentLoader / backend
- [ ] Нет hardcoded секретов в репозитории
- [ ] catalog.json и recommend_models согласованы

## C. UI / дизайн

- [ ] EtePalette используется консистентно
- [ ] SetupWizard: шаги, карточки, OptionCard
- [ ] SettingsWindow StyledCheck vs SetupWizard OptionCard — осознанное различие?
- [ ] HelpWindow: раздел «О продукте», клики mailto/t.me
- [ ] 10 языков: нет пустых fallback на EN

## D. Мастер и bootstrap

- [ ] probe на машине без Ollama — корректные сообщения
- [ ] probe с установленными моделями — «Установлена»
- [ ] install с --pdf2zh на чистой системе
- [ ] UTF-8 кириллица в recommendations

## E. Сборка и релиз

- [ ] cmake build Release успешен
- [ ] POST_BUILD копирует bootstrap и catalog
- [ ] Inno Setup script пути к exe
- [ ] CI workflows зелёные или задокументированы исключения

## F. Безопасность и лицензии

- [ ] AGPL PyMuPDF — заметка для дистрибуции
- [ ] pdf2zh / Ollama — third-party в engines/THIRD_PARTY.md
- [ ] update.json URLs только GitHub baddysays

## G. Итоговое заключение (заполнить ревьюером)

| Критерий | Оценка 1–5 | Комментарий |
|----------|------------|-------------|
| Архитектура | | |
| Качество кода | | |
| UI/UX | | |
| Документация | | |
| Готовность к релизу | | |

**Рекомендация:** ☐ Merge / ☐ Merge с правками / ☐ Требуется доработка

Подпись: _________________  Дата: ___________
