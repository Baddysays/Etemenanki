# 05 — Мастер настройки и bootstrap

## Файлы

- QML: `qml_cpp/SetupWizard.qml`
- C++: `cpp/setup_manager.cpp`, `cpp/setup_manager.h`
- Python: `tools/bootstrap/bootstrap.py`
- Манифест: `tools/bootstrap/install_manifest.json`

## Команда probe

```bash
python tools/bootstrap/bootstrap.py probe
```

**Выход (UTF-8 JSON):**

```json
{
  "ok": true,
  "ram_gb": 15.6,
  "vram_gb": 8.0,
  "hardware_tier": "balanced",
  "recommendations": [ ... ],
  "ollama_installed": ["translategemma:4b", ...],
  "deps": {
    "python": true,
    "python_path": "C:\\...\\.venv\\Scripts\\python.exe",
    "python_version": "3.14.5",
    "python_libs": true,
    "pdf2zh": true,
    "ollama": true
  }
}
```

## Логика рекомендаций моделей (balanced, ~16 GB RAM, 8 GB VRAM)

| Модель | recommended | Причина |
|--------|-------------|---------|
| translategemma:4b | ✅ | Default для balanced |
| qwen2.5:7b | ✅ | Второй pick для balanced |
| gemma2:9b | ❌ | Подходит по RAM, не в топ-2 |
| llama3.1:8b | ❌ | Ниже приоритет |
| translategemma:12b | ❌ | Нужно 10 GB VRAM, есть 8 |

`recommended = fits_hardware && is_recommended_for_tier(id, tier)`

## Команда install

```bash
python bootstrap.py install --pdf2zh --python-deps --ollama-models translategemma:4b qwen2.5:7b
```

Переменная окружения: `ETEMENANKI_ROOT` = папка с `Etemenanki.exe`.

## SetupManager (C++)

- `probeHardware()` — QProcess, `PYTHONIOENCODING=utf-8`
- `parseProbeJson()` — последняя JSON-строка из stdout
- `applyProbeResult()` — заполняет hardware, recommendations, depsStatus
- `runSetup()` — install, очищает log, по успеху `setSetupComplete(true)`

## QML свойства setup.*

| Property | Описание |
|----------|----------|
| `probeReady` | Скан завершён, есть recommendations |
| `hardware` | ram_gb, vram_gb, hardware_tier, tier_labels |
| `recommendations` | Список моделей с installed, recommended |
| `depsStatus` | python, pdf2zh, ollama, paths |
| `ollamaInstalled` | Имена из Ollama API |

## Первый запуск Main.qml

```qml
if (!setup.setupComplete)
    setupWizard.open()
```

`setupComplete` в QSettings.
