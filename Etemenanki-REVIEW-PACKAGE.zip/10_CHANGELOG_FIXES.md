# 10 — Журнал исправлений (сборка Release OK)

**Дата:** 2026-06-04  
**Сборка:** `cmake --build build --config Release` — успешно

## Исправленные баги

| # | Файл | Исправление |
|---|------|-------------|
| 1 | `qml_cpp/Main.qml` (корень) | Убраны `font.family` / `font.pixelSize` с корня `ApplicationWindow` (crash при загрузке QML) |
| 2 | `tools/pdf_engines.py` | JSON через `sys.stdout.buffer.write()` + `ensure_ascii=True` (кириллица в pipe) |
| 3 | `tools/export_document.py` | HTML-экранирование (`html.escape`) в HTML-экспорте |
| 4 | `tools/export_document.py` | XML-экранирование в EPUB-экспорте |
| 5 | `cpp/app_ui_strings_status.inc` | `%1` в `err_unsupported_format` (QString::arg) |
| 6 | `cpp/runtime_config.h.in` + `CMakeLists.txt` | Forward slashes в C-строках путей |
| 7 | `cpp/external_pdf_translate_worker.h/.cpp` | `bool m_cancelled` → `QAtomicInt m_cancelled` (data race) |
| 8 | `qml_cpp/SettingsWindow.qml` | `dlg.closed.connect(function() { dlg.destroy() })` (утечка диалога) |
| 9 | `qml_cpp/Main.qml` | `_ru` → динамический суффикс по `dstLangCode` |
| 10 | `qml_cpp/TranslationHub.qml` | Свои цвета заменены на токены `EtePalette` |

## Установщик и зависимости

| Компонент | Описание |
|-----------|----------|
| `installer/EtemenankiSetup.iss` | Inno Setup 6: VC++ Redistributable, опционально Python 3.12 embeddable, pip, pdf2zh, модели Ollama |
| `tools/install_deps.ps1` | PowerShell: Python embeddable + pip + pdf2zh + `ollama pull` |

## Связанные исправления (мастер настройки, ранее)

- `SetupWizard.qml` — font на Window, OptionCard, probe UTF-8
- `bootstrap.py` — `emit_json()` UTF-8, рекомендации моделей, Python probe
- `translator_backend.cpp` — `uiTr()` через AppUiStrings

## Для ревьюера

При проверке релиза убедиться, что в ISS и `install_deps.ps1` пути совпадают с фактической структурой `build/Release` после `windeployqt`.
