# 01 — Обзор проекта

## Название и позиционирование

- **Etemenanki** (не EtemenankiQt) — исполняемый файл `Etemenanki.exe`.
- Слоган: *«Нет легкого пути от земли к звездам»* — перевод документов с локальным ИИ или облаком.
- Организация Qt: `baddysays`.

## Целевая платформа

- **Windows 10/11 x64** (основная).
- Сборка: MSVC 2022, Qt 6.8 msvc2022_64.

## Основные сценарии пользователя

1. Скачать установщик или portable с GitHub Releases.
2. Установить Ollama отдельно, запустить `ollama serve`.
3. Первый запуск → **мастер настройки** (скан ПК, модели, pdf2zh, Python-библиотеки).
4. Загрузить документ → выбрать языки и модель → **Перевести** → **Сохранить**.
5. Для PDF с вёрсткой — движок pdf2zh или встроенный layout-pipeline.

## Форматы

| Формат | Подход |
|--------|--------|
| PDF | PyMuPDF / pdf_layout, pdf2zh для вёрстки |
| DOCX | python-docx через extract/export |
| TXT, MD | Прямой текст |
| XLSX, CSV | Ячейки |
| SRT, VTT | Субтитры |
| JSON, HTML, EPUB | Структурированное извлечение |

## Режимы перевода

- **Локально:** Ollama API (`http://127.0.0.1:11434`), модели из `assets/models_catalog.json`.
- **Облако:** DeepSeek, OpenAI-compatible — ключи в настройках (`AppSettings`).

## Интерфейс

10 языков UI: RU, EN, DE, FR, ES, UK, ZH, PT, EL, LA.  
Строки: `cpp/app_ui_strings.cpp` + генерируемые `.inc` файлы.

## Что вынесено из репозитория (очистка)

Удалены legacy-части: `review/`, `src/`, старый `qml/Main.qml`, `*.spec`, корневой `requirements.txt`, тестовые PDF, verify-скрипты. Актуальный UI только в `qml_cpp/`.

## GitHub

- Repo: https://github.com/Baddysays/Etemenanki  
- Release v1.0.0: portable zip + update.json (CI release workflow может падать на шаге Qt modules — см. doc 06).
