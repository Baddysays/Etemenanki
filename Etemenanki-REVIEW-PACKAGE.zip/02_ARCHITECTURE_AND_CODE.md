# 02 — Архитектура и код

## Стек

| Слой | Технология |
|------|------------|
| UI | Qt 6.8 Quick, QML, Qt Quick Controls 2 (стиль Basic) |
| Логика | C++20 |
| Документы | Python 3 (PyMuPDF, docx, openpyxl…) |
| PDF вёрстка | pdf2zh (portable в `engines/pdf2zh/`) |
| Локальный LLM | Ollama HTTP API |
| Сборка | CMake 3.21+, Inno Setup 6 |

## Точка входа

`cpp/main.cpp`:

- `QGuiApplication`, `QQmlApplicationEngine`
- Контекст QML: `settings` (AppSettings), `setup` (SetupManager), `backend` (TranslatorBackend)
- Загрузка `qrc:/Etemenanki/qml_cpp/Main.qml`
- Лог старта: `qml_startup.log` рядом с exe

## Ключевые C++ классы

### `AppSettings` (`app_settings.cpp/h`)

- QSettings: язык UI, Ollama URL, выбранная модель, облачные провайдеры, глоссарий.
- `refreshAvailableModels()` — опрос `/api/tags`, сопоставление с каталогом.
- `uiText(key, lang)` — локализованные строки.

### `TranslatorBackend` (`translator_backend.cpp/h`)

- Центр перевода: загрузка файла, чанки, запросы к Ollama/облаку.
- `updateModelInfo()` — RAM/VRAM labels, совместимость с моделью.
- `uiTr()` / `uiTrArgs()` — обёртка над `AppUiStrings`.
- PDF: copy для Python, external pdf2zh worker, layout extract.

### `DocumentLoader` (`document_loader.cpp/h`)

- Поиск Python: `tools/python_path.txt`, `.venv`, `engines/python`, PATH.
- `ensureReady()`, `probe()`, `runExtractScript`, `runPdfLayoutExtract`.
- Кэш пути Python, лог `python_debug.log`.

### `SetupManager` (`setup_manager.cpp/h`)

- Мастер первого запуска: `probeHardware()`, `runSetup()`.
- Запуск `tools/bootstrap/bootstrap.py probe|install`.
- OTA: `checkForUpdates()` по `releases/update.json`.

### `ExternalPdfTranslateWorker`

- Отдельный процесс pdf2zh для тяжёлых PDF.

### `TranslationWorkflow`

- Оркестрация шагов перевода.

## QML модули (`qml_cpp/`)

| Файл | Назначение |
|------|------------|
| `Main.qml` | Главное окно, хаб перевода, кнопки, модели |
| `SetupWizard.qml` | Мастер 3 шага: ПК → модели → компоненты |
| `SettingsWindow.qml` | Настройки, Ollama, облако, обновления |
| `HelpWindow.qml` | Справка «?», о продукте, контакты |
| `LangPicker.qml` | Выбор языка UI |
| `TranslationHub.qml` | Блок пайплайна |
| `EtePalette.qml` | Цвета, радиусы, шрифты |

## Python

| Путь | Роль |
|------|------|
| `tools/bootstrap/bootstrap.py` | probe RAM/VRAM, recommend models, install |
| `tools/extract_document.py` | Извлечение текста |
| `tools/export_document.py` | Экспорт результата |
| `tools/pdf_layout.py` | PDF по блокам |
| `tools/pdf2zh_runner.py` | Обёртка pdf2zh |
| `tools/pdf_engines.py` | Выбор PDF-движка |

## Данные

- `assets/models_catalog.json` — модели Ollama/cloud, tier, RAM/VRAM, labels RU/EN.
- `tools/bootstrap/install_manifest.json` — GitHub URLs, контакты, компоненты.
- `releases/update.json` — OTA metadata.

## Поток перевода (упрощённо)

```
Main.qml → backend.loadFile()
  → DocumentLoader (Python extract / PDF layout)
  → TranslatorBackend.translate()
    → Ollama /api/chat или cloud API
  → save → export_document / PDF rebuild
```

## Локализация статусов

- `tools/gen_status_ui_strings.py` → `cpp/app_ui_strings_status.inc`
- `tools/gen_main_ui_strings.py` → `cpp/app_ui_strings_main.inc`
- Динамические ошибки: `localizeStatusMessage()` по ключам `err_*`

## Сборка POST_BUILD (CMake)

Копирует в `build/Release/`: `assets/models_catalog.json`, `tools/*`, `tools/bootstrap/*`, `releases/update.json`.
